#Calculator app
A simple calculator built using HTML,CSS,Javascript,Bootstrap.
This project was developed as a part of a web development internship to practice core frontend concepts.

##Features
-Perform basic arithmetic operation:'+','-','*','/'.
-calculate modulo(%).
-Perform square of a number.
-Supports both decimal and whole numbers.
-'AC' (All Clear) button to clear the entire input.
-'back space button ' to clear current entry.
-'=' button to show results.
-Responsive layout using css flexbox,bootstrap.

##Technologies used
-HTML->structure of the calculator
-CSS and Bootstrap->Stling and responsive layout.
-JavaScript->logic using event listeners,functions,loops,if/else,and DOM methods.

Author
<br>
Sneha kv


